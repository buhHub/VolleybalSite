from flask import Flask, flash, redirect, render_template, request, session, url_for
import sqlite3
import os.path as path
import datetime
from fpdf import FPDF
from barcode import ISBN10
from barcode.writer import ImageWriter

F_exists = path.exists('IKEAdata.db')
print("File exists: "+str(F_exists))

app = Flask(__name__)


def requestdata(reflist):

    conn = sqlite3.connect('IKEAdata.db')
    c = conn.cursor()
    weekdays = ["MAANDAG", "DINSDAG", "WOENDSAG",
                "DONDERDAG", "VRIJDAG", "ZATERDAG", "ZONDAG"]

    DataList = []
    for refid in reflist:
        for id, name, start, end, ref, orderid1, orderid2, orderid3, dest in c.execute("SELECT * FROM clients WHERE Ref = ?", [int(refid)]):
            del_date = start.split(" ")[0].split("-")
            date = del_date[0] + "-" + del_date[1]
            formatteddate = weekdays[datetime.date(
                int(del_date[2]), int(del_date[1]), int(del_date[0])).weekday()]
            timeslot = start.split(" ")[1] + "-" + end.split(" ")[1]
            DataList.append([ref, name, date, formatteddate,
                             timeslot, orderid1, orderid2, orderid3, dest])
    return DataList


def AanmakenPapieren(datalist, location):

    if len(datalist) > 0:
        pdf_editor = FPDF(orientation='L', unit='mm', format='A4')
        pdf_editor.set_margins(left=0, top=0, right=0)

        for data in datalist:
            ISBN10(str(data[0]), writer=ImageWriter()).save("barcode")

            pdf_editor.add_page()

            # IKEA LOGO
            pdf_editor.set_xy(10, 10)
            pdf_editor.set_font('Arial', 'B', 40)
            pdf_editor.cell(w=50, h=40, txt="IKEA",
                            border=1, align='C', fill=False)
            pdf_editor.set_font('Arial', '', 12)
            pdf_editor.set_xy(34, 38)
            pdf_editor.cell(w=1, h=1, txt="EINDHOVEN",
                            border=0, align='C', fill=False)

            # WEEKDAG
            pdf_editor.set_xy(60, 10)
            pdf_editor.set_font('Arial', 'B', 64)
            pdf_editor.cell(
                w=177, h=40, txt=data[3], border=1, align='C', fill=False)

            # Picking ID
            pdf_editor.set_xy(237, 10)
            pdf_editor.rect(x=237, y=10, w=50, h=40)
            pdf_editor.set_font('Arial', 'B', 36)
            if location == "CZM":
                pdf_editor.set_xy(262, 27)
                pdf_editor.cell(w=1, h=1, txt=str(
                    data[5]), border=0, align='C', fill=False)
                pdf_editor.set_xy(262, 40)
                pdf_editor.cell(w=1, h=1, txt=str(
                    data[6]), border=0, align='C', fill=False)
            else:
                pdf_editor.set_xy(262, 32)
                pdf_editor.cell(w=1, h=1, txt=str(
                    data[7]), border=0, align='C', fill=False)
            pdf_editor.set_font('Arial', 'B', 18)
            pdf_editor.set_xy(262, 16)
            pdf_editor.cell(w=1, h=1, txt="PICKING ID",
                            border=0, align='C', fill=False)

            # NAAM
            pdf_editor.set_xy(10, 50)
            pdf_editor.set_font('Arial', 'B', 64)
            pdf_editor.cell(
                w=277, h=40, txt=data[1], border=1, align='C', fill=False)
            pdf_editor.set_font('Arial', '', 12)
            pdf_editor.set_xy(297/2, 53)
            pdf_editor.cell(w=1, h=1, txt="NAAM", border=0,
                            align='C', fill=False)

            # POSTCODE
            pdf_editor.set_xy(10, 90)
            pdf_editor.set_font('Arial', 'B', 64)
            pdf_editor.cell(w=80, h=40, txt="5616",
                            border=1, align='C', fill=False)
            pdf_editor.set_font('Arial', '', 12)
            pdf_editor.set_xy(50, 93)
            pdf_editor.cell(w=1, h=1, txt="POSTCODE",
                            border=0, align='C', fill=False)

            # PLAATSNAAM
            pdf_editor.set_xy(90, 90)
            pdf_editor.set_font('Arial', 'B', 64)
            pdf_editor.cell(
                w=197, h=40, txt=data[8], border=1, align='C', fill=False)
            pdf_editor.set_font('Arial', '', 12)
            pdf_editor.set_xy(90 + 197/2, 93)
            pdf_editor.cell(w=1, h=1, txt="PLAATSNAAM",
                            border=0, align='C', fill=False)

            # DATUM
            pdf_editor.set_xy(10, 130)
            pdf_editor.set_font('Arial', 'B', 72)
            pdf_editor.cell(
                w=100, h=57, txt=data[2], border=1, align='C', fill=False)
            pdf_editor.set_font('Arial', '', 12)
            pdf_editor.set_xy(60, 133)
            pdf_editor.cell(w=1, h=1, txt="DATUM",
                            border=0, align='C', fill=False)

            # TIJDSBLOK
            pdf_editor.set_xy(110, 130)
            pdf_editor.rect(x=110, y=130, w=60, h=57)
            pdf_editor.set_font('Arial', 'B', 48)
            pdf_editor.set_xy(140, 150)
            pdf_editor.cell(w=1, h=1, txt=data[4].replace(
                ":00", "").split("-")[0], border=0, align='C', fill=False)
            pdf_editor.set_xy(140, 170)
            pdf_editor.cell(w=1, h=1, txt=data[4].replace(
                ":00", "").split("-")[1], border=0, align='C', fill=False)
            pdf_editor.set_font('Arial', '', 12)
            pdf_editor.set_xy(140, 133)
            pdf_editor.cell(w=1, h=1, txt="TIJDSBLOK",
                            border=0, align='C', fill=False)

            # ORDERNUMMER
            pdf_editor.set_xy(170, 130)
            pdf_editor.set_font('Arial', 'B', 40)
            pdf_editor.cell(w=117, h=25, txt=str(
                data[0]), border=1, align='C', fill=False)
            pdf_editor.set_font('Arial', '', 12)
            pdf_editor.set_xy(170 + 117/2, 133)
            pdf_editor.cell(w=1, h=1, txt="ORDERNUMMER",
                            border=0, align='C', fill=False)

            # CZM
            pdf_editor.set_xy(170, 155)
            pdf_editor.set_font('Arial', 'B', 40)
            if data[5] != 0 or data[6] != 0:
                pdf_editor.cell(w=117/2, h=32, txt="X",
                                border=1, align='C', fill=False)
            else:
                pdf_editor.cell(w=117/2, h=32, txt="",
                                border=1, align='C', fill=False)
            pdf_editor.set_font('Arial', '', 12)
            pdf_editor.set_xy(170 + 117/4, 133 + 25)
            pdf_editor.cell(w=1, h=1, txt="CZM", border=0,
                            align='C', fill=False)

            # EMPU
            pdf_editor.set_xy(170+(117/2), 155)
            pdf_editor.set_font('Arial', 'B', 40)
            if data[7] != 0:
                pdf_editor.cell(w=117/2, h=32, txt="X",
                                border=1, align='C', fill=False)
            else:
                pdf_editor.cell(w=117/2, h=32, txt="",
                                border=1, align='C', fill=False)
            pdf_editor.set_font('Arial', '', 12)
            pdf_editor.set_xy(170 + 3*117/4, 133 + 25)
            pdf_editor.cell(w=1, h=1, txt="EMPU", border=0,
                            align='C', fill=False)

            # ORDER LOCATIONS
            pdf_editor.set_font('Arial', '', 60)
    #        print(location)
            if location == "CZM":
                pdf_editor.set_xy(170+(117/4)-0.5, 171)
            else:
                pdf_editor.set_xy(170+(3*117/4)-0.5, 171)
            pdf_editor.cell(w=1, h=1, txt="[_]",
                            border=0, align='C', fill=False)

            # BARCODE
            pdf_editor.image("barcode.png", x=230, y=192,
                             w=40, h=15, type='png', link='')

        pdf_editor.output(name='static/dagaanduiding.pdf', dest='')

    pass

# REMOVE CACHING POSSIBILITIES [PDF WILL UPDATE AFTER REFRESH]


@app.after_request
def add_header(r):
    """
    Add headers to both force latest IE rendering engine or Chrome Frame,
    and also to cache the rendered page for 10 minutes.
    """
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    r.headers['Cache-Control'] = 'public, max-age=0'
    return r

# HOMEPAGE


@app.route('/')
def index():
    return render_template('home.html')

# THIS CAN BE DELETED, ITS OVERWRITED BY THE RESULTS PAGE


@app.route('/paperwork', methods=['GET', 'POST'])
def paperwork():
    if request.method == 'POST':

        #        print("paperwork posted")
        FormNames = ["A", "B", "C", "D", "E", "F"]
        RefList = [request.form.get(
            FormName) for FormName in FormNames if request.form.get(FormName)]

        DataList = requestdata(RefList)
        return redirect(url_for('results', data=[RefList], len_list=10, location="CZM"))

    print("paperwork getted")
    return render_template('paperwork.html')

# NEW PAGE TO MAKE THE PAPERS


@app.route('/results', methods=['GET', 'POST'])
def results():

    # POST DATA
    if request.method == 'POST':

        ###################
        # Retrieve basic information of the situation
        #   n_entries [The number of allowed entries selected by the bottom left input
        #   location  [CZM or EMPU, helper for PDF maker]
        #   printer   [1 if element for printing, else 0]
        ###################

        n_entries = int(request.form.get("number"))
        location = request.form.get("location")
        printer = [1 if request.form.get(str(x)) == "on" else 0 for x in range(
            100, (n_entries + 1) * 100, 100)]

        # DETERMINE IF TASK BUTTON IS PRESSED
        if 'task' in dict(request.form).keys():

            # DETERMINE WHICH TASK TO DO
            if request.form['task'] == 'Maak Dagaanduidingen':
                RefList = [request.form.get(str(i)) for i in range(
                    n_entries) if request.form.get(str(i))]
                PrintList = [RefList[i]
                             for i in range(len(RefList)) if printer[i]]
                AanmakenPapieren(requestdata(PrintList), location)
                RefList = [RefList[i]
                           for i in range(len(RefList)) if not printer[i]]
            elif request.form['task'] == 'Update':
                RefList = [request.form.get(str(i)) for i in range(
                    n_entries) if request.form.get(str(i))]
            elif request.form['task'] == 'Verwijder Alles':
                RefList = []
            else:
                pass  # unknown
        else:
            RefList = [request.form.get(str(i)) for i in range(
                n_entries) if request.form.get(str(i))]

        # REDIRECT BACK TO THE GET FUNCTION
        return redirect(url_for('results', data=[RefList], len_list=n_entries, location=location))

    # GET DATA

    ####################
    # Retrieve information of the situation
    #   location   [CZM or EMPU, helper for PDF maker]
    #   RefList    [List with current 'ordernummers']
    #   datas      [All data processed using RefList]
    ####################

    location = request.args['location']

    if len(request.args['data']) != 2:
        RefList = [int(ref) for ref in request.args['data']
                   [1:-1].replace("'", "").split(", ")]
    else:
        RefList = []

    datas = requestdata(RefList)

    # CHECK IS PDF FILE EXISTS
    PDFexists = path.exists('static/dagaanduiding.pdf')
    print("File exists: "+str(PDFexists))

    return render_template('results.html', list=datas, n_list=len(datas), number=int(request.args['len_list']), location=location, pdf=PDFexists)


if __name__ == '__main__':
    app.run(debug=True)
