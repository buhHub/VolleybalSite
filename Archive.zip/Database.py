import sqlite3
import os.path as path

F_exists = path.exists('IKEAdata.db')
print("File exists: "+str(F_exists))

conn = sqlite3.connect('IKEAdata.db')
c = conn.cursor()

if F_exists:
    print("shait")
    c.execute("CREATE TABLE CLIENTS ([id] INTEGER PRIMARY KEY,[Client_Name] text, [Begin_date] text, [End_date] text, [Ref] INTEGER, [order_id1] INTEGER, [order_id2] INTEGER, [order_id3] INTEGER, [dest] text)")
    testdata = [("Buh", "8-2-2021 9:00", "8-2-2021 15:00", 116324, 56356, 56357, 0, "Veldhoven"),
        ("Yen", "8-2-2021 9:00", "8-2-2021 15:00", 116322, 56232, 0, 56233, "Eindhoven"),
        ("Lys", "8-2-2021 13:00", "8-2-2021 19:00", 116323, 56489, 56490, 56491, "Venlo"),
        ("Pei", "8-2-2021 9:00", "8-2-2021 15:00", 116321, 56849, 56850, 0, "Deurne"),
        ("Kar", "8-2-2021 16:00", "8-2-2021 22:00", 116325, 0, 56712, 0, "Helvoirt"),
        ("John", "10-2-2021 9:00", "10-2-2021 15:00", 116326, 0, 56921, 56922, "Valkenswaard"),
        ("Jam", "12-2-2021 16:00", "12-2-2021 22:00", 116327, 0, 0, 56385, "'S-Hertogenbosch"),
        ("Sja", "8-2-2021 16:00", "8-2-2021 22:00", 116328, 56940, 0, 0, "Tilburg")
    ]
    c.executemany("INSERT INTO CLIENTS (Client_name, Begin_date, End_date, Ref, order_id1, order_id2, order_id3, dest) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", testdata)
    conn.commit()

name = "Yen"
for row in c.execute("SELECT * FROM CLIENTS"):
    print(row)
